package com.restugedepurnama.event

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.restugedepurnama.event.data.response.DetailEventResponse
import com.restugedepurnama.event.databinding.ActivityDetailBinding
import com.restugedepurnama.event.viewModel.DetailViewModel

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel: DetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getStringExtra("EVENT_ID")
        detailViewModel.getEventDetailById(eventId.toString())

        detailViewModel.detailEventObject.observe(this) {
            showDetailEvent(it)
        }

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val customTitleView = layoutInflater.inflate(R.layout.custome_action_bar_title, supportActionBar?.customView as? ViewGroup, false)
        supportActionBar?.customView = customTitleView
        supportActionBar?.setDisplayShowCustomEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun showDetailEvent(detailEvent: DetailEventResponse) {
        val description = detailEvent.event?.description ?: ""
        binding.tvDescription.text = HtmlCompat.fromHtml(description, HtmlCompat.FROM_HTML_MODE_LEGACY,  ImageGetter(binding.tvDescription), null)

        val customTitleView = supportActionBar?.customView?.findViewById<TextView>(R.id.action_bar_title)
        customTitleView?.text = detailEvent.event?.name

        binding.btnNavigate.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(detailEvent.event?.link)
            startActivity(intent)
        }
    }

    class ImageGetter(val textView: TextView) : Html.ImageGetter {

        override fun getDrawable(source: String?): Drawable {
            val placeholder = BitmapDrawable(textView.resources, Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888))

            Glide.with(textView.context)
                .asBitmap()
                .load(source)
                .into(object : CustomTarget<Bitmap>() {
                    @RequiresApi(Build.VERSION_CODES.S)
                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                        val parentWidth = textView.width
                        val aspectRatio = resource.height.toFloat() / resource.width.toFloat()
                        val height = (parentWidth * aspectRatio).toInt()

                        val drawable = BitmapDrawable(textView.resources, resource)
                        drawable.setBounds(0, 0, parentWidth, height)

                        placeholder.setBounds(0, 0, parentWidth, height)
                        placeholder.bitmap = resource

                        textView.text = textView.text
                        textView.invalidate()
                    }

                    override fun onLoadCleared(placeholder: Drawable?) {
                        // Handle case when the load is cleared, if needed
                    }
                })
            return placeholder
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_EVENT_ID = "EVENT_ID"
    }
}