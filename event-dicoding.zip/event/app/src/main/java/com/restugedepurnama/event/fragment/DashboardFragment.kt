package com.restugedepurnama.event.fragment

import android.content.Context
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.restugedepurnama.event.R
import com.restugedepurnama.event.adapter.EventFinishedAdapter
import com.restugedepurnama.event.adapter.SearchAdapter
import com.restugedepurnama.event.broadcast.ConnectivityReceiver
import com.restugedepurnama.event.databinding.FragmentDashboardBinding
import com.restugedepurnama.event.viewModel.DashboardViewModel

class DashboardFragment : Fragment() {

    private lateinit var binding: FragmentDashboardBinding
    private val dashboardViewModel by viewModels<DashboardViewModel>()
    private val pastEventAdapter = EventFinishedAdapter()
    private val searchAdapter = SearchAdapter()
    private lateinit var connectivityReceiver: ConnectivityReceiver

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding) {
            rvDashboard.apply {
                adapter = pastEventAdapter
                layoutManager = LinearLayoutManager(requireContext())
            }

            dashboardViewModel.listFinishedEvents.observe(viewLifecycleOwner) {
                pastEventAdapter.submitList(it)
            }

            dashboardViewModel.isLoading.observe(viewLifecycleOwner) {
                showLoading(it)
            }

            dashboardViewModel.listSearchEvents.observe(viewLifecycleOwner) {
                searchAdapter.submitList(it)
                binding.errorMessage.visibility = if (it!!.isEmpty()) View.VISIBLE else View.GONE
            }

            searchView.setupWithSearchBar(searchBar)
            searchView.editText.apply {
                setOnEditorActionListener { _, _, _ ->
                    searchEvent(searchView.editText.text.toString())
                    setRecyclerView()

                    val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(searchView.windowToken, 0)

                    dashboardViewModel.listSearchEvents.observe(requireActivity()) {
                        if (it.isNullOrEmpty()) {
                            showNotFound(true)
                        } else {
                            showNotFound(false)
                        }
                    }

                    false
                }

                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        if (s.isNullOrEmpty()) {

                            binding.errorMessage.visibility = View.VISIBLE
                        } else {
                            binding.errorMessage.visibility = View.GONE
                        }
                    }

                    override fun afterTextChanged(s: Editable?) {}
                })
            }

        }

        connectivityReceiver = ConnectivityReceiver { isConnected ->
            if (!isConnected) {
                binding.errorMessage.visibility = View.VISIBLE
                binding.errorMessage.text = getString(R.string.no_internet_connection)
            } else {
                binding.errorMessage.visibility = View.GONE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        requireContext().registerReceiver(connectivityReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        requireContext().unregisterReceiver(connectivityReceiver)
    }

    private fun setRecyclerView() {
        binding.rvSearch.apply {
            adapter = searchAdapter
            layoutManager = LinearLayoutManager(requireContext())
        }
    }

    private fun showNotFound(isDataNotFound: Boolean) {
        binding.apply {
            if (isDataNotFound) {
                rvSearch.visibility = View.GONE
                errorMessageSearch.visibility = View.VISIBLE
            } else {
                rvSearch.visibility = View.VISIBLE
                errorMessageSearch.visibility = View.GONE
            }
        }
    }

    private fun searchEvent(query: String) {
        dashboardViewModel.searchEvent(query)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}

