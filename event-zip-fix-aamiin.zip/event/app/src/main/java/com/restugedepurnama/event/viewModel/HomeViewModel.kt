package com.restugedepurnama.event.viewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.restugedepurnama.event.data.response.EventActiveResponse
import com.restugedepurnama.event.data.response.ListEventsItem
import com.restugedepurnama.event.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel : ViewModel() {

    private val _listUpcomingEvents = MutableLiveData<List<ListEventsItem>?>()
    val listUpcomingEvents: LiveData<List<ListEventsItem>?> = _listUpcomingEvents

    private val _listFinishedEvents = MutableLiveData<List<ListEventsItem>?>()
    val listFinishedEvents: LiveData<List<ListEventsItem>?> = _listFinishedEvents

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    companion object {
        private const val TAG = "MainActivity"
    }

    init {
        getListUpcomingEvents()
        getListFinishedEvents()
    }

    private fun getListUpcomingEvents() {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getEvents(1)
        client.enqueue(object : Callback<EventActiveResponse> {
            override fun onResponse(
                call: Call<EventActiveResponse>,
                response: Response<EventActiveResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _listUpcomingEvents.value = response.body()?.listEvents
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<EventActiveResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun getListFinishedEvents() {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getEvents(0)
        client.enqueue(object : Callback<EventActiveResponse> {
            override fun onResponse(
                call: Call<EventActiveResponse>,
                response: Response<EventActiveResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _listFinishedEvents.value = response.body()?.listEvents
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<EventActiveResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }
}