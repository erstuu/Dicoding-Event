package com.restugedepurnama.event.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.restugedepurnama.event.adapter.EventUpcomingPageAdapter
import com.restugedepurnama.event.databinding.FragmentUpcomingBinding
import com.restugedepurnama.event.viewModel.UpcomingViewModel

class UpcomingFragment : Fragment() {

    private lateinit var binding: FragmentUpcomingBinding
    private val upcomingViewModel by viewModels<UpcomingViewModel>()
    private val upcomingEventAdapter = EventUpcomingPageAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        binding = FragmentUpcomingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding) {
            rvUpcomingPage.apply {
                adapter = upcomingEventAdapter
                layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
            }

            upcomingViewModel.listUpcomingEvents.observe(viewLifecycleOwner) {
                upcomingEventAdapter.submitList(it)
            }

            upcomingViewModel.isLoading.observe(viewLifecycleOwner) {
                showLoading(it)
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}