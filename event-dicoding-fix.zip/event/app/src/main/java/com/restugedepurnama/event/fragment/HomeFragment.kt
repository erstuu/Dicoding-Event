package com.restugedepurnama.event.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.restugedepurnama.event.databinding.FragmentHomeBinding
import com.restugedepurnama.event.adapter.EventFinishedAdapter
import com.restugedepurnama.event.adapter.EventUpcomingAdapter
import com.restugedepurnama.event.viewModel.HomeViewModel

class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private val mainViewModel by viewModels<HomeViewModel>()
    private val upcomingEventAdapter = EventUpcomingAdapter()
    private val pastEventAdapter = EventFinishedAdapter()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        with(binding) {
            rvEventUpcoming.apply {
                adapter = upcomingEventAdapter
                layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
            }

            rvEventActive.apply {
                adapter = pastEventAdapter
                layoutManager = LinearLayoutManager(requireContext())
            }

            mainViewModel.listUpcomingEvents.observe(viewLifecycleOwner) {
                upcomingEventAdapter.submitList(it)
            }

            mainViewModel.listFinishedEvents.observe(viewLifecycleOwner) {
                pastEventAdapter.submitList(it)
            }


            mainViewModel.isLoading.observe(viewLifecycleOwner) {
                showLoading(it)
            }

        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.loading.apply {
            visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }
}