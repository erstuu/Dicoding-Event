package com.restugedepurnama.event

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.restugedepurnama.event.data.response.DetailEventResponse
import com.restugedepurnama.event.databinding.ActivityDetailBinding
import com.restugedepurnama.event.viewModel.DetailViewModel

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel: DetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getStringExtra("EVENT_ID")
        detailViewModel.getEventDetailById(eventId.toString())

        detailViewModel.detailEventObject.observe(this) {
            showDetailEvent(it)
        }

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportActionBar?.title = "Detail Event"
        supportActionBar?.setDisplayShowCustomEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    private fun showDetailEvent(detailEvent: DetailEventResponse) {
        val imageUrl = detailEvent.event?.mediaCover ?: ""
        val title = detailEvent.event?.name ?: ""
        val ownerName = detailEvent.event?.ownerName ?: ""
        val date = detailEvent.event?.beginTime ?: ""
        val quota = detailEvent.event?.quota ?: 0
        val description = detailEvent.event?.description ?: ""

        Glide.with(this)
            .load(imageUrl)
            .into(binding.imgEvent)
        binding.tvTitleEvent.text = title
        binding.tvOwnerName.text = ownerName
        binding.tvBeginTime.text = date
        binding.quota.text = quota.toString()
        binding.tvDescription.text = HtmlCompat.fromHtml(description, HtmlCompat.FROM_HTML_MODE_LEGACY)

        val customTitleView = supportActionBar?.customView?.findViewById<TextView>(R.id.action_bar_title)
        customTitleView?.text = detailEvent.event?.name

        binding.btnNavigate.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(detailEvent.event?.link)
            startActivity(intent)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_EVENT_ID = "EVENT_ID"
    }
}