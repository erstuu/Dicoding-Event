package com.restugedepurnama.event.viewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.restugedepurnama.event.data.response.EventActiveResponse
import com.restugedepurnama.event.data.response.ListEventsItem
import com.restugedepurnama.event.data.response.SearchEventResponse
import com.restugedepurnama.event.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UpcomingViewModel : ViewModel() {

    private val _listUpcomingEvents = MutableLiveData<List<ListEventsItem>?>()
    val listUpcomingEvents: LiveData<List<ListEventsItem>?> = _listUpcomingEvents

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    init {
        getListUpcomingEvents()
    }

    private fun getListUpcomingEvents() {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getEvents(1)
        client.enqueue(object : Callback<EventActiveResponse> {
            override fun onResponse(
                call: Call<EventActiveResponse>,
                response: Response<EventActiveResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    Log.d(TAG, "onResponse: ${response.body()?.listEvents}")
                    _listUpcomingEvents.value = response.body()?.listEvents
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<EventActiveResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    companion object {
        private const val TAG = "Upcoming Fragment"
    }
}